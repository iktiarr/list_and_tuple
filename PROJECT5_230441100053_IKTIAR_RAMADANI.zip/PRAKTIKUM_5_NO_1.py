menu = []

while True:
    jumlah_data = int(input("Anda ingin memasukkan berapa data? "))
    print("")
    if jumlah_data < 1:
        print("Data harus minimal 1 atau lebih")
        break

    data_valid = True
    for i in range(jumlah_data):
        makanan = input(f"Masukkan nama makanan ke-{i + 1}: ")
        while not makanan.isalpha():
            print("Nama makanan salah")
            ulangi = input("Ingin mengulang dari awal? (y/t): ")
            print("")
            if ulangi.lower() != "y":
                data_valid = False
                break
            makanan = input(f"Masukkan nama makanan ke-{i + 1}: ")

        if not data_valid:
            break

        harga = input(f"Masukkan harga makanan ke-{i + 1}: ")
        while not harga.isdigit():
            print("Harga makanan salah")
            ulangi = input("Ingin mengulang dari awal? (y/t): ")
            print("")
            if ulangi.lower() != "y":
                data_valid = False
                break
            harga = input(f"Masukkan harga makanan ke-{i + 1}: ")

        if not data_valid:
            break

        menu.append((makanan, float(harga)))

    if data_valid:
        break

print("Hasil data di atas:")
print("")
for item in menu:
    print(f"{item[0]} memiliki harga sebesar Rp. {item[1]}")
