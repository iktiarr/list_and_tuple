data_mahasiswa = []

while True:
    jumlah_data = int(input("Anda ingin memasukkan berapa data mahasiswa? "))
    print("")
    if jumlah_data < 1:
        print("Data harus minimal 1 atau lebih")
        ulangi = input("Ingin mengulang dari awal? (y/t): ")
        print("")
        if ulangi.lower() == "y":
            continue
        else:
            print("Terima kasih!")
            break

    for i in range(jumlah_data):
        while True:
            nim = input("Masukkan NIM ke-" + str(i + 1) + "          : ")
            if not nim.isdigit() or '<1' in nim:
                print("NIM harus angka positif")
                ulangi = input("Ingin mengulang NIM ini? (y/t): ")
                if ulangi.lower() == "y":
                    continue
            break

        while True:
            nama = input("Masukkan Nama ke-" + str(i + 1) + "         : ")
            if not nama.isalpha():
                print("Nama harus huruf")
                ulangi = input("Ingin mengulang Nama ini? (y/t): ")
                if ulangi.lower() == "y":
                    continue
            break

        while True:
            prodi = input("Masukkan Program Studi ke-" + str(i + 1) + ": ")
            if not prodi.isalpha():
                print("Prodi harus huruf")
                ulangi = input("Ingin mengulang Program Studi ini? (y/t): ")
                if ulangi.lower() == "y":
                    continue
            break

        alamat = input("Masukkan Alamat ke-" + str(i + 1) + "       : ")
        mahasiswa = (nim, nama, prodi, alamat)
        data_mahasiswa.append(mahasiswa)

    while True:
        cari = input("Masukkan Program Studi yang ingin dicari: ")
        print("")

        data_akhir = []

        for mahasiswa in data_mahasiswa:
            if mahasiswa[2] == cari:
                data_akhir.append(mahasiswa)

        if data_akhir:
            print("Berikut data Mahasiswa Program Studi", cari, ":")
            for mahasiswa in data_akhir:
                print("NIM:", mahasiswa[0])
                print("Nama:", mahasiswa[1])
                print("Prodi:", mahasiswa[2])
                print("Alamat:", mahasiswa[3])
                print("")
        else:
            print("Tidak ditemukan data mahasiswa untuk Program Studi", cari)

        ulangi = input("Apakah ingin mencari lagi? (y/t): ")
        if ulangi.lower() != "y":
            break